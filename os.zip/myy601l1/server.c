/* server.c

   Sample code of 
   Assignment L1: Simple multi-threaded key-value server
   for the course MYY601 Operating Systems, University of Ioannina 

   (c) S. Anastasiadis, G. Kappes 2016

*/


#include <signal.h>
#include <sys/stat.h>
#include "utils.h"
#include "kissdb.h"
#include <sys/time.h>

#define MY_PORT                 6767
#define BUF_SIZE                1160
#define KEY_SIZE                 128
#define HASH_SIZE               1024
#define VALUE_SIZE              1024
#define MAX_PENDING_CONNECTIONS   10

#define SIZE 10 //gia to megethos ths ouras
#define NUM_THREADS 5
// Definition of the operation type.
typedef enum operation {
  PUT,
  GET
} Operation; 

// Definition of the request.
typedef struct request {
  Operation operation;
  char key[KEY_SIZE];  
  char value[VALUE_SIZE];
} Request;

// Definition of the database.
KISSDB *db = NULL;

//statistics
int completed_requests;
double total_service_time;
double total_waiting_time;

/*shmaforoi gia thn oura*/
/*MUTual EXclusion*/
/*mutex: gia thn oura kai thn prosvash se auth*/
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
/*timemutex: gia prosvash sthn auxhsh twn statistikwn
 *       dld na mhn pane dyo nhmata katanalwtes na auxisoun tautoxrono tis metavlites
 *       mporei na prokypsei kapoio race condition*/
pthread_mutex_t timemutex = PTHREAD_MUTEX_INITIALIZER;
/*condition variable*/
//non_full_queue: gia na perimenei o paragwgos otan h oure einai gemath
//non_empty_queue: gia na perimenei o katanalwths otan h oura einai adeia
pthread_cond_t non_full_queue  = PTHREAD_COND_INITIALIZER;
pthread_cond_t non_empty_queue = PTHREAD_COND_INITIALIZER;


/*queue*/
//pinakas pou apothikeuei tis aithseis apo tous clients.
//ousiastika ton FD ths syndeshs (auto pou epistrefei h accept) (auto pou xrhsimopoioume gia na epikoinwnhsoume me ton client)
struct item{
	int fd; 
	struct timeval arrive; //pote eftase h aithsh sto systhma
};

//pinakas (global) me size stoixeia gia na apothikeuei to kyriws nhma tis aithseis.
struct item Q[SIZE];
int count; //posa stoixeia exei mesa h oura
int qstart; //mou deixnei poia einai h arxh ths ouras

void init();
void terminate(int signumber);
int isEmpty();
int isFull();
void insert_last(int fd,struct timeval arrive);
struct item remove_first();

//anagnwstes - grafeis
int reader_count;
int writer_count;
pthread_mutex_t readwrite_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t non_readers = PTHREAD_COND_INITIALIZER;
pthread_cond_t non_writers = PTHREAD_COND_INITIALIZER;
/**
 * @name parse_request - Parses a received message and generates a new request.
 * @param buffer: A pointer to the received message.
 *
 * @return Initialized request on Success. NULL on Error.
 */
Request *parse_request(char *buffer) {
  char *token = NULL;
  Request *req = NULL;
  
  // Check arguments.
  if (!buffer)
    return NULL;
  
  // Prepare the request.
  req = (Request *) malloc(sizeof(Request));
  memset(req->key, 0, KEY_SIZE);
  memset(req->value, 0, VALUE_SIZE);

  // Extract the operation type.
  token = strtok(buffer, ":");    
  if (!strcmp(token, "PUT")) {
    req->operation = PUT;
  } else if (!strcmp(token, "GET")) {
    req->operation = GET;
  } else {
    free(req);
    return NULL;
  }
  
  // Extract the key.
  token = strtok(NULL, ":");
  if (token) {
    strncpy(req->key, token, KEY_SIZE);
  } else {
    free(req);
    return NULL;
  }
  
  // Extract the value.
  token = strtok(NULL, ":");
  if (token) {
    strncpy(req->value, token, VALUE_SIZE);
  } else if (req->operation == PUT) {
    free(req);
    return NULL;
  }
  return req;
}

/*
 * @name process_request - Process a client request.
 * @param socket_fd: The accept descriptor.
 *
 * @return
 */
void process_request(const int socket_fd) {
  char response_str[BUF_SIZE], request_str[BUF_SIZE];
    int numbytes = 0;
    Request *request = NULL;

    // Clean buffers.
    memset(response_str, 0, BUF_SIZE);
    memset(request_str, 0, BUF_SIZE);
    
    // receive message.
    numbytes = read_str_from_socket(socket_fd, request_str, BUF_SIZE);
    
    // parse the request.
    if (numbytes) {
      request = parse_request(request_str);
      if (request) {
        switch (request->operation) {
			//------ reader -------
          case GET:
            pthread_mutex_lock(&readwrite_mutex);
            //an yparxei kapoio writer kai kanei PUT tote prepei na perimenw mexri na fygei
            //kai na me enhmerwsei oti mporw na xypnhsw (katastash apokleismou)
		while(writer_count == 1){
			pthread_cond_wait(&non_writers, &readwrite_mutex);
		}
		reader_count ++; //pleon yparxei kai enas reader akomh giati mpainw na kanw read.
            pthread_mutex_unlock(&readwrite_mutex);
            // Read the given key from the database.
            if (KISSDB_get(db, request->key, request->value))
              sprintf(response_str, "GET ERROR\n");
            else
              sprintf(response_str, "GET OK: %s\n", request->value);
            pthread_mutex_lock(&readwrite_mutex);
            reader_count--; //feugei o reader ara meiwnontai
            if(reader_count==0){ //an einai o teleytaios pou feugei tote na 3ypnhsei an yparxoun writers.
				pthread_cond_broadcast(&non_writers);
			}
            pthread_mutex_unlock(&readwrite_mutex);
            
            break;
            //----- writer ----------
          case PUT:
			
            pthread_mutex_lock(&readwrite_mutex);
            //an yparxei allos writer tote prepei na perimenei
            //opws kai an yparxoun reader tote prepei na perimenei
            while(writer_count == 1 || reader_count > 0){
				//an yparxei allos writer tote perimenw sthn oura twn writers
				if(writer_count==1){
					pthread_cond_wait(&non_writers,&readwrite_mutex);
				}
				//alliws perimenw sthn oura twn readers
				else{
					pthread_cond_wait(&non_readers,&readwrite_mutex);
				}
			}
			//otan telika mpainei writer kanw thn metavliti writer_count = 1
			writer_count = 1;
            pthread_mutex_unlock(&readwrite_mutex);
          
            // Write the given key/value pair to the database.
            if (KISSDB_put(db, request->key, request->value)) 
              sprintf(response_str, "PUT ERROR\n");
            else
              sprintf(response_str, "PUT OK\n");
             
            //teleiwnei enas writer
		pthread_mutex_lock(&readwrite_mutex);
		writer_count = 0; //vganei o writer pou ekane PUT
		//prepei na 3ekollhsei osous perimenoun gia auto to logw
		//pthread_cond_signal(&non_writers): xypnaei ena, ton prwto pou perimenei
		pthread_cond_broadcast(&non_writers); //xypnaei osous perimenoun. mas endiaferei an yparxoun polloi reader na tous xypnhsw
		pthread_mutex_unlock(&readwrite_mutex);
			
              
              
            break;
          default:
            // Unsupported operation.
            sprintf(response_str, "UNKOWN OPERATION\n");
        }
        // Reply to the client.
        write_str_to_socket(socket_fd, response_str, strlen(response_str));
        if (request)
          free(request);
        request = NULL;
        return;
      }
    }
    // Send an Error reply to the client.
    sprintf(response_str, "FORMAT ERROR\n");
    write_str_to_socket(socket_fd, response_str, strlen(response_str));
}

/*
 * @name main - The main routine.
 *
 * @return 0 on success, 1 on error.
 */
int main() {

  int socket_fd,              // listen on this socket for new connections
      new_fd;                 // use this socket to service a new connection
  socklen_t clen;
  struct sockaddr_in server_addr,  // my address information
                     client_addr;  // connector's address information
	
	struct timeval start;
	
  // create socket
  if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    ERROR("socket()");

  // Ignore the SIGPIPE signal in order to not crash when a
  // client closes the connection unexpectedly.
  signal(SIGPIPE, SIG_IGN);
  
  // create socket adress of server (type, IP-adress and port number)
  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);    // any local interface
  server_addr.sin_port = htons(MY_PORT);
  
  // bind socket to address
  if (bind(socket_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) == -1)
    ERROR("bind()");
  
  // start listening to socket for incomming connections
  listen(socket_fd, MAX_PENDING_CONNECTIONS);
  fprintf(stderr, "(Info) main: Listening for new connections on port %d ...\n", MY_PORT);
  clen = sizeof(client_addr);

  // Allocate memory for the database.
  if (!(db = (KISSDB *)malloc(sizeof(KISSDB)))) {
    fprintf(stderr, "(Error) main: Cannot allocate memory for the database.\n");
    return 1;
  }
  
  // Open the database.
  if (KISSDB_open(db, "mydb.db", KISSDB_OPEN_MODE_RWCREAT, HASH_SIZE, KEY_SIZE, VALUE_SIZE)) {
    fprintf(stderr, "(Error) main: Cannot open the database.\n");
    return 1;
  }

	//arxikopoihsh olws twn metavlitwn gia thn ylopoihsh ths askhshs
	init();
	// main loop: wait for new connection/requests
	while (1) { 
		// wait for incomming connection
		if ((new_fd = accept(socket_fd, (struct sockaddr *)&client_addr, &clen)) == -1) {
			ERROR("accept()");
		}

		// got connection, serve request
		//fprintf(stderr, "(Info) main: Got connection from '%s'\n", inet_ntoa(client_addr.sin_addr));
		/* O Neo kwdikas*/
		//start: pote ftanei h aithsh sto systhma
		gettimeofday(&start,NULL);
		//critical
		pthread_mutex_lock(&mutex);
		while(isFull()==1){ //an h oura den einai gemath tote thn vazei thn aithsh mesa
			//oso einai gemath prepei na perimenei, dld koimatai o paragwgos
			pthread_cond_wait(&non_full_queue,&mutex);
		}
		insert_last(new_fd,start);
		//an evala ena stoixeio tote prepei na xypnhsw tous katanalwtes
		if(count>=1) pthread_cond_signal(&non_empty_queue);
		pthread_mutex_unlock(&mutex);
	

		/*
		gettimeofday(&start,NULL);
		process_request(new_fd);
		close(new_fd);
		gettimeofday(&end,NULL);
		
		service_time = (end.tv_sec - start.tv_sec) + 
						(end.tv_usec - start.tv_usec)/1000000.0;
		completed_requests++;
		total_service_time += service_time;
		*/
	}  

  // Destroy the database.
  // Close the database.
  KISSDB_close(db);

  // Free memory.
  if (db)
    free(db);
  db = NULL;

  return 0; 
}


/*auth thn synarthsh tha thn trexou ta nhmata katanalwtes pou tha exyphretoun tis aithsei*
 */
void *consumer_thread(void *ptr)
{
	struct item it;
	struct timeval start, end;
	//oi consumers trexoun epanlhptika kai exyphretoun aithseis
	while(1){
		//an h oura einai adeia perimenei
		//critical section: arxh
		pthread_mutex_lock(&mutex);
		while(isEmpty() ==1 ){
			//otan h oura einai adeia prepei na perimenei o katanalwths
			//1.prepei na exoume kleidwmeno to shmaforo
			//2.3ekleidwnei ton shmafora (mutex)
			//3. Mpainei se apokleismo
			//4. Otan tou steilei shma o allos tote tha xypnhsei
			//5. Afou xypnhsei kleidwnei xana ton shmaforo (mutex)
			pthread_cond_wait(&non_empty_queue,&mutex);
		}
		//vgazei mia aithsh
		it = remove_first();
		//evgala ena stoixeio apo thn oura ara prepei na xypnhsei ton paragwgo an perimene
		if(count<SIZE) pthread_cond_signal(&non_full_queue);
		//critical section: telos
		pthread_mutex_unlock(&mutex);
		//pairnei xrono pote 3ekinaei na thn e3hpyreti
		gettimeofday(&start,NULL);
		//thn exyphretei
		process_request(it.fd);
		close(it.fd);
		//pairnei xrono pote teleiwse
		gettimeofday(&end,NULL);	
		
		pthread_mutex_lock(&timemutex);
		total_service_time = total_service_time + (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec)/1000000.0;
		total_waiting_time = total_waiting_time + (start.tv_sec - it.arrive.tv_sec) + (start.tv_usec - it.arrive.tv_usec)/1000000.0;
		completed_requests = completed_requests + 1; 
		pthread_mutex_unlock(&timemutex);
	}
	return NULL;
}

//otan pathsei to ctrl+z tote kaleitai auth h synarthsh
void terminate(int signumber)
{
	printf("Exiting\n");
	if(completed_requests>0){
		printf("CR: %5d\n",completed_requests);
		printf("Average Service Time:%f\n",total_service_time/completed_requests);
		printf("Average Waiting Time:%f\n",total_waiting_time/completed_requests);
	}
	else {
		printf("No requests served\n");
	}
	exit(0);
}

//gia thn arxikopoihsh olwn ton metavlitwn.
void init()
{
	pthread_t tid;
	int i;
	
	
	/*arxikopoihsh metrhtwn gia statistika*/
	completed_requests = 0;
	total_waiting_time = 0.0;
	total_service_time = 0.0;
	
	/*arxikopoihsh ouras*/
	qstart = 0;
	count = 0;
	
	/*anagnwstes - egrafeis*/
	reader_count = 0;
	writer_count = 0;
	
	//oti einai global sto programma to vlepoun ola ta nhmata
	
	//dhmiourgei nhma 4 orismata
	//1o: mas epistrefei to TID
	//2o: ta attributes tou nhmatos, mporoume na ta allaxoume, NULL=>default
	//          p.x. megethos stoivas tou nhmatos
	//3o: poia synarthsh tha ektelei to nhma. Otan auth termatisei tote termatizei to nhma
	//4o: ta arguments tis synarthshs tou nhmatos. NULL => tipota. Oti dedomena xreiazetai tha ta diavazei apo thn stoiva pou einai koinoxrhsth
	for(i=0; i<NUM_THREADS; i++){
		pthread_create(&tid,NULL,consumer_thread,NULL);
	}
	
	//SIGTSTP=> ctrl+z
	//leei sto leitourgiko pws otan o xrhsths pathsei to ctrl+z, kai ftasei sthn diergasia to shma SIGTSTP
	//tote to programma tha kalesei thn terminate.
	signal(SIGTSTP,terminate);
	
	
}


void insert_last(int fd,struct timeval arrive){
	int p = (qstart + count)%SIZE;
	Q[p].fd = fd;
	Q[p].arrive = arrive;
	count++;
}

/*epistrefei ena stoixeio apo thn oura*/
struct item remove_first(){
	struct item x;
	
	x = Q[qstart];
	qstart = (qstart + 1)%SIZE;
	count--;
	return x;
}


int isFull(){
	if(count==SIZE) return 1;
	return 0;
}

int isEmpty(){
	if(count==0)	return 1;
	return 0;
}




/****GIA ANAFORA****/
/*
 * 1. Ti exoume ylopoihsei sto programma. Dld pws douleue prin kai pws douleuei meta. (sxhma) xwris kwdika
 * 2. Perigrafh ths oura kai ti apothikeuei.
 * 3. Ti kanei o paragwgos (xwris kwdika) (kyriws nhma)
 * 4. TI kanoun oi katanalwtes (xwris kwdika)
 * 5. Pws teleiwnei to programma (ctrl+z) (shma klp) (ctrl+c xwris stats)
 * 6. Ti allages kaname ston client.
 */























